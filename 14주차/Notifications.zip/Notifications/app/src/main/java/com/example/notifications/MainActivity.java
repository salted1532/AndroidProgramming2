package com.example.notifications;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.graphics.Color;
import android.os.Build;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int NOTIFY_1 = 0x1011;

    private NotificationManager notifier = null;
    Notification notify = new Notification();

    Button btn01;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btn01 = (Button) findViewById(R.id.button01);

        btn01.setOnClickListener(this);

        notifier = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, MODE_PRIVATE);
        }
    }

    @Override
    public void onClick(View v) {
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {

        }

        String expandedTitle = "E-Title";
        String expandedText = "Context";

        Intent toLaunch = new Intent(MainActivity.this, Notification.class);

        PendingIntent intentBack = PendingIntent.getActivity(MainActivity.this, 0, toLaunch, PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);

        if(Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            notify = new Notification.Builder(getApplication())
                    .setContentTitle(expandedTitle)
                    .setContentText(expandedText)
                    .setSmallIcon(R.drawable.notifications_24px)
                    .setAutoCancel(true)
                    .setContentIntent(intentBack)
                    .setWhen(System.currentTimeMillis())
                    .build();
        }


        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channelMessage = new NotificationChannel("channel_id", "channel_name", NotificationManager.IMPORTANCE_DEFAULT);

            channelMessage.setDescription("channel description");
            channelMessage.enableLights(true);
            channelMessage.setLightColor(Color.GREEN);
            channelMessage.enableVibration(true);
            channelMessage.setVibrationPattern(new long[]{100, 200, 100, 200});
            channelMessage.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            notifier.createNotificationChannel(channelMessage);

            notify = new Notification.Builder(getApplication(), "channel_id")
                    .setContentTitle(expandedTitle)
                    .setContentText(expandedText)
                    .setSmallIcon(R.drawable.notifications_circle_24px)
                    .setAutoCancel(true)
                    .setContentIntent(intentBack)
                    .setWhen(System.currentTimeMillis())
                    .build();
        }

        notifier.notify(NOTIFY_1, notify);
    }
}