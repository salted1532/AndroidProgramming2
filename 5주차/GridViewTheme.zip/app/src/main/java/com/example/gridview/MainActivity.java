package com.example.gridview;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener {

    public static Integer[] mThumbIds = { R.drawable.a1, R.drawable.a2,R.drawable.a3,R.drawable.a4,R.drawable.a5,
                                          R.drawable.a6,R.drawable.a7,R.drawable.a8,R.drawable.a9,R.drawable.a10,
                                          R.drawable.a11,R.drawable.a12,R.drawable.a13,R.drawable.a14 };

    GridView grid01;
    Button btn01;

    static TextView text01;
    static TextView text02;
    static ImageView image01;
    static int size = 0;

    public static String[] mString_title = {"A","B","C","D","E","F",
            "G","H","I","J","K",
            "L","M","N"};
    public static String[] mString_body = {"A1","B2","C3","D4","E5","F6",
            "G7","H8","I9","J10","K11",
            "L12","M13","N14"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        grid01 = (GridView) findViewById(R.id.gridView01);
        grid01.setOnClickListener(this);

        grid01.setAdapter(new ImageAdapter(this));

        grid01.setNumColumns(3);
        grid01.setColumnWidth(GridView.AUTO_FIT);
        grid01.setHorizontalSpacing(10);
        grid01.setVerticalSpacing(10);
        grid01.setGravity(Gravity.CENTER);
        grid01.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);

        int width_size = this.getResources().getDisplayMetrics().widthPixels;
        //int height_size = this.getResources().getDisplayMetrics().heightPixels;

        size = width_size/3;



        btn01 = (Button) findViewById(R.id.button01);
        btn01.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        finish();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int i, long l) {
        Intent intent01 = new Intent(MainActivity.this, ImageViewActivity.class);
        intent01.putExtra("key", i);

        startActivity(intent01);

    }

    private static class ImageAdapter extends BaseAdapter {
        private final Context mContext;

        LayoutInflater inflater;

        public ImageAdapter(Context context) {

            mContext = context;

            inflater =(LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        }

        @Override
        public int getCount() {
            return mThumbIds.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return mThumbIds[i];
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            if(view == null) {
                view = inflater.inflate(R.layout.data_layout, null) ;
            }
            image01 = (ImageView) view.findViewById(R.id.data_imageView);
            text01 = (TextView) view.findViewById(R.id.textView01);
            text02 = (TextView) view.findViewById(R.id.textView02);

            image01.setImageResource(mThumbIds[i]);
            text01.setText(mString_title[i]);
            text02.setText(mString_body[i]);

            return view;

//            ImageView imageView01;
//            if(view == null) {
//                imageView01 = new ImageView(mContext);
//                imageView01.setLayoutParams(new ViewGroup.LayoutParams(size - 15 , size - 15));
//                imageView01.setScaleType(ImageView.ScaleType.CENTER_CROP);
//                imageView01.setPadding(8,8,8,8);
//            } else {
//                imageView01 = (ImageView)view;
//            }
//            imageView01.setImageResource(mThumbIds[i]);
//            return imageView01;
        }
    }
}


