package com.example.recyclerview;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

public class MainActivity extends AppCompatActivity {

    Button btn01;

    RecyclerView recyclerView01;
    RecyclerView.Adapter adapter;

    private final String[] items = {"item 01","item 02","item 03","item 04","item 05",
                                    "item 06","item 07","item 08","item 09","item 10",
                                    "item 11","item 12","item 13","item 14","item 15" };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btn01 = (Button) findViewById(R.id.button01);
        btn01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }

        });


        recyclerView01 = (RecyclerView)findViewById(R.id.recycler01);

        //recyclerView01.setLayoutManager(new LinearLayoutManager(this));
        //recyclerView01.setLayoutManager(new GridLayoutManager(this, 3));
        recyclerView01.setLayoutManager(new StaggeredGridLayoutManager(1, LinearLayoutManager.VERTICAL));


        adapter = new RecyclerAdapter(items);

        recyclerView01.setAdapter(adapter);

    }

    private class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder>
    {

        String[] data_items;

        public RecyclerAdapter(String[] items) {
            data_items = items;
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {

            TextView data_text01;
            Button data_btn01;
            Button data_btn02;
            public MyViewHolder(@NonNull View itemView)
            {
                super(itemView);

                this.data_text01 = itemView.findViewById(R.id.data_textView01);
                this.data_btn01 = itemView.findViewById(R.id.data_button01);
                this.data_btn02 = itemView.findViewById(R.id.data_button02);

                data_btn02.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Toast.makeText(getBaseContext(), "test", Toast.LENGTH_LONG).show();
                    }
                });

                data_text01.setOnClickListener(new View.OnClickListener(){

                    @Override
                    public void onClick(View view) {
                        int position = getAdapterPosition(); //별도에 메소드로 위치 정보 가져옴
                        Toast.makeText(getBaseContext(), "ITEM = " + position, Toast.LENGTH_LONG).show();
                    }
                });

            }

        }

        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            //View hoolderView = LayoutInflater.from(parent.getContext()).inflate(R.layout.data_layout, parent, false);
            //MyViewHolder myViewHolder = new MyViewHolder(hoolderView);

            Context context = parent.getContext();
            LayoutInflater inflater = LayoutInflater.from(context);
            View hoolderView = inflater.inflate(R.layout.data_layout, parent, false);

            MyViewHolder myViewHolder = new MyViewHolder(hoolderView);

            return myViewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            holder.data_text01.setText(data_items[position]);
        }

        @Override
        public int getItemCount() {
            return data_items.length;
        }
    }



}