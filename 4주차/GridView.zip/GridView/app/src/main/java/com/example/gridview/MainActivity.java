package com.example.gridview;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    public static Integer[] mThumbIds = { R.drawable.a1, R.drawable.a2,R.drawable.a3,R.drawable.a4,R.drawable.a5,
                                          R.drawable.a6,R.drawable.a7,R.drawable.a8,R.drawable.a9,R.drawable.a10,
                                          R.drawable.a11,R.drawable.a12,R.drawable.a13,R.drawable.a14 };

    GridView grid01;
    Button btn01;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        grid01 = (GridView) findViewById(R.id.gridView01);

        grid01.setAdapter(new ImageAdapter(this));

        btn01 = (Button) findViewById(R.id.button01);
        btn01.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        finish();
    }

    private static class ImageAdapter extends BaseAdapter {
        private final Context mContext;

        public ImageAdapter(Context context) {
            mContext = context;
        }

        @Override
        public int getCount() {
            return mThumbIds.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return mThumbIds[i];
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            ImageView imageView01;
            if(view == null) {
                imageView01 = new ImageView(mContext);
                imageView01.setLayoutParams(new ViewGroup.LayoutParams(85, 85));
                imageView01.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView01.setPadding(8,8,8,8);
            } else {
                imageView01 = (ImageView)view;
            }
            imageView01.setImageResource(mThumbIds[i]);
            return imageView01;
        }
    }
}


