package com.example.a0521app;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.Telephony;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btn01;

    TextView textView01;

    ContentResolver cr;

    Cursor c;

    StringBuffer buff;

    String[] projection;


    TelephonyManager telephony;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btn01 = (Button) findViewById(R.id.button01);

        btn01.setOnClickListener(this);

        textView01 = (TextView) findViewById(R.id.textView01);

        textView01.setMovementMethod(new ScrollingMovementMethod());

        buff = new StringBuffer();
        buff.append("History \n\n");

//        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CALL_LOG}, MODE_PRIVATE);

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CONTACTS}, MODE_PRIVATE);

        if(Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
            ActivityCompat.requestPermissions(this, new String[]
                    {Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CONTACTS}, MODE_PRIVATE);
        }
        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
            ActivityCompat.requestPermissions(this, new String[]
                    {Manifest.permission.READ_PHONE_NUMBERS, Manifest.permission.READ_CONTACTS}, MODE_PRIVATE);
        }

        telephony = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

//        projection = new String[] {
//                CallLog.Calls.TYPE,
//                CallLog.Calls.NUMBER,
//                CallLog.Calls.DURATION
//        };

        projection = new String[] {
                ContactsContract.CommonDataKinds.Phone._ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
        };
    }

    @Override
    public void onClick(View view) {
        cr = getContentResolver();

//        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG)
//                != PackageManager.PERMISSION_GRANTED) {
//            return;
//        }

        if(Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
            if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG)
                != PackageManager.PERMISSION_GRANTED) {
                return;
            }
        }
        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
            if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG)
                    != PackageManager.PERMISSION_GRANTED) {
                return;
            }
        }

//        c = cr.query(CallLog.Calls.CONTENT_URI, projection,
//                null, null, "date desc");

        c = cr.query(CallLog.Calls.CONTENT_URI, projection,
                null, null, null);


//        if(c.moveToFirst()) {
//            do{
//                if(c.getInt(0) == CallLog.Calls.INCOMING_TYPE) {
//                    buff.append("<--INCOMING");
//                }
//                if(c.getInt(0) == CallLog.Calls.MISSED_TYPE) {
//                    buff.append("-?- MISSED");
//                }
//                if(c.getInt(0) == CallLog.Calls.REJECTED_TYPE) {
//                    buff.append("-X- DECLINE");
//                }
//                if(c.getInt(0) == CallLog.Calls.OUTGOING_TYPE) {
//                    buff.append("--> OUTGOING");
//                }
//
//                buff.append("\t : ");
//                buff.append(c.getString(1));
//                buff.append("\t : ");
//                buff.append(c.getInt(2));
//                buff.append("\t : \n");
//                buff.append("--------------------\n");
//
//                Date date1 = new Date(c.getLong(3));
//
//                SimpleDateFormat date_format =
//                        new SimpleDateFormat("yyyy/MM//dd HH:mm:ss a");
//                String date2 = date_format.format(date1);
//                buff.append("--------------------\n");
//
//            } while(c.moveToNext());
//        }

        if(c.moveToFirst()) {
            do{
                buff.append(c.getString(0));
                buff.append("\n : ");
                buff.append(c.getString(1));
                buff.append("\n : ");
                buff.append(c.getString(2));
                buff.append("\n : ");
            } while(c.moveToNext());
        }

        c.close();

        String telPhoneNo = telephony.getLine1Number();

        buff.append("My Number : " + telPhoneNo);

        textView01.setText(buff);

    }
}